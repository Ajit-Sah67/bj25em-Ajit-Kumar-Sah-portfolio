"use strict";

const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

menuToggle.addEventListener("click", () => {
  const isExpanded = menuToggle.getAttribute("aria-expanded") === "true";
  menuToggle.setAttribute("aria-expanded", String(!isExpanded));
  menuToggle.setAttribute("aria-label", isExpanded ? "Open navigation menu" : "Close navigation menu");
  navLinks.classList.toggle("is-open", !isExpanded);
});

navLinks.addEventListener("click", (event) => {
  if (event.target instanceof HTMLAnchorElement) {
    navLinks.classList.remove("is-open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation menu");
  }
});

const htmlNameInput = document.querySelector("#html-name");
const htmlGreeting = document.querySelector("[data-greeting]");
document.querySelector("[data-greet]").addEventListener("click", () => {
  const name = htmlNameInput.value.trim();
  htmlGreeting.textContent = name ? `Hello, ${name}!` : "Enter a name to see a greeting.";
});

const greetingForm = document.querySelector("[data-js-form]");
const visitorName = document.querySelector("#visitor-name");
const greetingResult = document.querySelector("[data-js-result]");
greetingForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const name = visitorName.value.trim();

  if (name) {
    greetingResult.textContent = `Hello, ${name}! Thanks for exploring this JavaScript example.`;
  } else {
    greetingResult.textContent = "Please enter your name to continue.";
    visitorName.focus();
  }
});
